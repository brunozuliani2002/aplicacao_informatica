package br.com.infox.telas;

import javax.swing.*;

public class Tela5Pagamento {
    private JLabel JLPagamento;
    private JLabel JLEscolhaPagamento;
    private JLabel JLChavePix;
    private JTextField textFieldChavePix;
    private JLabel JLNumeroCartao;
    private JTextField textFieldNumeroCartao;
    private JLabel JLValor;
    private JTextField txtValorAPagar;
    private JButton btnconfirmarPagamentoButton;
    private JRadioButton rbPix;
    private JRadioButton rbCartao;

    public static void main(String[] args) {

    }
}
