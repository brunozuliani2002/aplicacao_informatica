package br.com.senac.view;

import javax.swing.*;

public class TelaCadastroUser {
    private JPanel JPTelaCadastroUser;
    private JLabel JLTituloTchefood;
    private JLabel JLNome;
    private JTextField textField1;
    private JLabel JLSenha;
    private JTextField textField3;
    private JButton cadastrarButton;
    private JButton voltarButton;
}
